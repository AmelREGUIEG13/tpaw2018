function validation() {

    var nom = document.getElementById("nom").value;
    var prenom = document.getElementById("Prénom").value;


    if (nom.length < 5) {
        document.getElementById("error").innerHTML = "la saisie du nom est obligatoire ";
        document.getElementById("error").style.backgroundcolor = "#FFB6C1";
        

    }
    else {
        document.getElementById("result").innerHTML = "Bienvenue" + document.querySelector("#nom").value;
        document.getElementById("result").style.backgroundcolor = "green";
    }
}
